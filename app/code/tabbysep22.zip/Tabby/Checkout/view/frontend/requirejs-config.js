var config = {
    config: {
        mixins: {
            'Magento_Swatches/js/swatch-renderer': {
                'Tabby_Checkout/js/mixin/swatch-renderer': true
            }
        }
    }
};
