<?php

namespace Tabby\Checkout\Exception;

use Magento\Framework\Exception\LocalizedException;

class NotAuthorizedException extends LocalizedException
{
}
