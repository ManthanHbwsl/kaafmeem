# ElasticSuite Core Functional Tests

The Functional Test Module for **ElasticSuite Core** module.
