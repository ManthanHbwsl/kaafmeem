## README

Readme for the whole Smile ElasticSuite is available [here](https://github.com/Smile-SA/elasticsuite).
