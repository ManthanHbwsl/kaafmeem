<?php
namespace Tabby\Checkout\Controller\Result;

class Failure extends Cancel
{
    const MESSAGE = 'Payment with Tabby is failed';
}

