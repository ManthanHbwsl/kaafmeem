<?php
namespace Tabby\Checkout\Exception;

class NotAuthorizedException extends \Magento\Framework\Exception\LocalizedException {
}
