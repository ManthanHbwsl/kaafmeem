<?php
namespace Tabby\Checkout\Exception;

class NotFoundException extends \Magento\Framework\Exception\LocalizedException {
}
